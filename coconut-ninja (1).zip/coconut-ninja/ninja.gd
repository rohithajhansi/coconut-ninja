extends Node2D
# the ninja. he just keeps bouncing, you steer him left/right

const GRAVITY = 1400
const BOUNCE = -750
const SPEED = 300
const GROUND = 460

var vel_y = 0.0
var facing = 1
var slash_time = 0.0

func _process(delta):
	var dir = Input.get_axis("ui_left", "ui_right")
	if dir > 0:
		facing = 1
	elif dir < 0:
		facing = -1
	position.x += dir * SPEED * delta
	position.x = clamp(position.x, 20, 940)

	# gravity + bounce
	vel_y += GRAVITY * delta
	position.y += vel_y * delta
	if position.y >= GROUND:
		position.y = GROUND
		vel_y = BOUNCE

	if slash_time > 0:
		slash_time -= delta
	queue_redraw()

func slash():
	slash_time = 0.2

func _draw():
	# TODO: swap these shapes for real sprites
	draw_circle(Vector2.ZERO, 18, Color("222222"))
	draw_rect(Rect2(-18, -8, 36, 7), Color("e53935"))   # headband
	draw_circle(Vector2(facing * 6, -5), 3, Color.WHITE) # eye
	if slash_time > 0:
		draw_arc(Vector2.ZERO, 75, 0, TAU, 24, Color.WHITE, 4)
