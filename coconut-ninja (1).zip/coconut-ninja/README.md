# Coconut Ninja
Hackathon game, theme: Bounce Back.
Bounce around, slice the coconuts before they hit you.

Arrows = move, Space/click = slash, R = restart
Godot 4.3+

main.gd    - game loop, spawning, score (person 1)
ninja.gd   - player (person 2)
coconut.gd - coconuts (person 3)
