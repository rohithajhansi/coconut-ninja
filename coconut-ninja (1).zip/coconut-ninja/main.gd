extends Node2D
# main game script: spawns coconuts, checks hits, keeps score

var NinjaScript = preload("res://ninja.gd")
var CoconutScript = preload("res://coconut.gd")

var trees = [120, 360, 600, 840]
var ninja
var coconuts = []
var spawn_timer = 1.0
var time_alive = 0.0
var cuts = 0
var dead = false
var score_label
var over_label

func _ready():
	ninja = NinjaScript.new()
	ninja.position = Vector2(480, 460)
	add_child(ninja)

	score_label = Label.new()
	score_label.position = Vector2(20, 15)
	score_label.add_theme_font_size_override("font_size", 24)
	add_child(score_label)

	over_label = Label.new()
	over_label.position = Vector2(300, 220)
	over_label.add_theme_font_size_override("font_size", 40)
	over_label.text = "You got coconutted!\nPress R to bounce back"
	over_label.visible = false
	add_child(over_label)

func _input(event):
	if dead:
		return
	if event.is_action_pressed("ui_accept") or (event is InputEventMouseButton and event.pressed):
		ninja.slash()
		# cut any coconut close to the ninja
		for c in coconuts.duplicate():
			if c.position.distance_to(ninja.position) < 90:
				coconuts.erase(c)
				c.queue_free()
				cuts += 1

func _process(delta):
	if dead:
		if Input.is_key_pressed(KEY_R):
			get_tree().reload_current_scene()
		return

	time_alive += delta

	# drop a new coconut every so often (gets faster)
	spawn_timer -= delta
	if spawn_timer <= 0:
		var c = CoconutScript.new()
		c.position = Vector2(trees[randi() % 4] + randf_range(-40, 40), 70)
		add_child(c)
		coconuts.append(c)
		spawn_timer = max(0.5, 1.5 - time_alive * 0.02)

	for c in coconuts.duplicate():
		if c.age > 12:
			coconuts.erase(c)
			c.queue_free()
		elif c.position.distance_to(ninja.position) < 30:
			dead = true
			over_label.visible = true

	score_label.text = "Time: " + str(int(time_alive)) + "   Cut: " + str(cuts)

func _draw():
	draw_rect(Rect2(0, 0, 960, 540), Color("8fd3ff"))     # sky
	draw_rect(Rect2(0, 500, 960, 40), Color("1e88c9"))    # water
	for t in trees:
		draw_rect(Rect2(t - 8, 70, 16, 410), Color("8b5a2b"))
		draw_circle(Vector2(t, 70), 45, Color("2e9e4f"))
	draw_rect(Rect2(0, 480, 960, 20), Color("e53935"))    # trampoline
