extends Node2D
# a coconut. falls, bounces on the trampoline too

var vel = Vector2.ZERO
var age = 0.0

func _ready():
	vel.x = randf_range(-60, 60)

func _process(delta):
	vel.y += 700 * delta
	position += vel * delta
	age += delta

	# bounce off the trampoline
	if position.y >= 466:
		position.y = 466
		vel.y = -max(abs(vel.y) * 0.9, 450)
	queue_redraw()

func _draw():
	# TODO: real coconut art
	draw_circle(Vector2.ZERO, 14, Color("4e342e"))
	draw_circle(Vector2(-4, -4), 3, Color("8d6e63"))
